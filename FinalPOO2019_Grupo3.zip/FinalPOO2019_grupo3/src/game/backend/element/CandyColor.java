package game.backend.element;

public enum CandyColor {

	RED, GREEN, BLUE, YELLOW, ORANGE, PURPLE

}
