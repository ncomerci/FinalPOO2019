el inicio del juego se encuentra en src/game/frontend/GameApp.java

en caso de que no compile, revisar que esté bien asignado el PATH de la carpeta resources
en el compilador y que el PATH del audio en MainMenu.java y GameState.java sea correcto.